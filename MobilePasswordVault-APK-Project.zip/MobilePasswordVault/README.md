# Mobile Password Vault APK 🔐📱

Ini adalah project Android sederhana untuk mengubah file HTML password vault menjadi aplikasi APK.

Aplikasi ini hanya membuka file `index.html` di dalam Android WebView.

---

## Isi Project

File penting:

```txt
app/src/main/assets/index.html
app/src/main/java/com/amran/mobilevault/MainActivity.java
.github/workflows/build-apk.yml
```

---

## Cara Paling Mudah Build APK Tanpa Install Android Studio

Gunakan GitHub Actions.

### 1. Upload Project ke GitHub

Upload semua isi folder project ini ke repository GitHub.

Pastikan struktur repository seperti ini:

```txt
.github/workflows/build-apk.yml
app/build.gradle
app/src/main/assets/index.html
build.gradle
settings.gradle
README.md
```

### 2. Buka Menu Actions

Di GitHub, buka repository kamu, lalu pilih menu:

```txt
Actions
```

### 3. Jalankan Build

Pilih workflow:

```txt
Build APK
```

Lalu klik:

```txt
Run workflow
```

Tunggu sampai proses selesai.

### 4. Download APK

Kalau build berhasil, buka hasil workflow, lalu download artifact:

```txt
MobilePasswordVault-debug-apk
```

Di dalamnya ada file APK:

```txt
app-debug.apk
```

Install file itu di HP Android.

---

## Cara Ganti Isi Aplikasi

Edit file:

```txt
app/src/main/assets/index.html
```

Kalau ingin mengganti tampilan, fitur, warna, atau teks, ubah file HTML itu.

Setelah itu upload/commit lagi ke GitHub, lalu jalankan build APK ulang.

---

## Catatan Penting

Jangan upload data password asli ke GitHub.

Yang aman diupload:

```txt
Project aplikasi
index.html
README.md
```

Yang jangan diupload:

```txt
backup-mobile-password-vault.json
daftar-password.txt
catatan password
```

---

## Master Password

Aplikasi tidak punya password bawaan.

Saat pertama kali dibuka, masukkan master password sendiri.

Contoh:

```txt
AmranVault@2026
```

Jangan lupa master password. Kalau lupa, data tidak bisa dibuka lagi.

---

## Status

Project ini cocok untuk aplikasi pribadi, belajar, dan password vault sederhana.
